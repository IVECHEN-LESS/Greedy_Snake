

from PIL import Image

def bmp_to_verilog_txt(bmp_file, txt_file):
    # 打开 BMP 图像文件
    img = Image.open(bmp_file)

    # 将图像转换为 RGB 模式，确保每个像素有 R, G, B 通道
    img = img.convert('RGB')

    # 获取图像尺寸
    width, height = img.size

    # 打开文本文件用于保存 Verilog 格式的初始化数据
    with open(txt_file, 'w') as f:
        #f.write("initial begin\n")
        
        # 遍历每个像素并拼接 RGB 通道数据
        for y in range(height):
            for x in range(width):
                r, g, b = img.getpixel((x, y))
                # 保留每个通道的最高 4 位
                r = (r >> 5) & 0x07  # 取最高 3 位
                g = (g >> 5) & 0x07  # 取最高 3 位
                b = (b >> 5) & 0x07  # 取最高 3 位
                # 拼接成 12 位数据：R (4 bits) | G (4 bits) | B (4 bits)
                pixel_data = (r << 6) | (g << 3) | b
                # 输出 Verilog 格式的赋值语句
                f.write(f"  mem_r[{y*width + x + 16384}] = 9'b{pixel_data:09b};\n")
        
        #f.write("end\n")

# 使用函数读取 BMP 文件并生成 Verilog 初始化文本
bmp_file = 'icon_dead.bmp'  # 替换为实际的 BMP 文件路径
txt_file = 'mem.txt'      # 输出的 Verilog 文本文件路径
bmp_to_verilog_txt(bmp_file, txt_file)


