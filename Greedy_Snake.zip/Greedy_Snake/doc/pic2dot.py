

from PIL import Image

def bmp_to_verilog_txt(bmp_file, txt_file):
    # 打开 BMP 图像文件
    img = Image.open(bmp_file)

    # 将图像转换为 RGB 模式，确保每个像素有 R, G, B 通道
    img = img.convert('RGB')

    # 获取图像尺寸
    width, height = img.size

    # 打开文本文件用于保存 Verilog 格式的初始化数据
    with open(txt_file, 'w') as f:
        f.write("initial begin\n")
        
        # 遍历每个像素并拼接 RGB 通道数据
        for y in range(height):
            row_data = ""  # 用来存储该行的拼接字符串数据
            for x in range(width):
                r, g, b = img.getpixel((x, y))
                # 保留每个通道的最高 4 位
                r = (r >> 4) & 0x0F  # 取最高 4 位
                g = (g >> 4) & 0x0F  # 取最高 4 位
                b = (b >> 4) & 0x0F  # 取最高 4 位
                # 拼接成 12 位数据：R (4 bits) | G (4 bits) | B (4 bits)
                pixel_data = r
                # 如果拼接后的 12 位数据大于 0，则该像素值为 1，否则为 0
                # 如果拼接后的 12 位数据大于 0，则该像素值为 1，否则为 0
                if pixel_data > 10:
                    row_data = '1' + row_data  # 拼接 '1'
                else:
                    row_data = '0' + row_data  # 拼接 '0'
                # 输出 Verilog 格式的赋值语句
                #f.write(f"  mem_r[{y*width + x}] = {width}'b{pixel_data:01b};\n")
            # 输出该行的 1 位拼接数据，格式为 Verilog 的赋值语句
            f.write(f"  mem_r[{y}] = {width}'b{row_data};\n")
        f.write("end\n")

# 使用函数读取 BMP 文件并生成 Verilog 初始化文本
bmp_file = 'Greedy_Snake.bmp'  # 替换为实际的 BMP 文件路径
txt_file = 'logo.txt'      # 输出的 Verilog 文本文件路径
bmp_to_verilog_txt(bmp_file, txt_file)


